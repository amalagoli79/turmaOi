namespace Back_End_ER02.Interfaces
{
    public interface IPessoa
    {
         float CalcularImposto (float rendimento);
    }
}