namespace Back_End_ER02.Interfaces
{
    public interface IPessoaJuridica
    {
         bool ValidarCnpj (string cnpj);
    }
}